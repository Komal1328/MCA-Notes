#h6.1

def out():
    def in_add(a,b):
        return a+b
    n1=int(input("Enter the first number: "))
    n2=int(input("Enter the second number: "))
    return (in_add(n1,n2)+5)
print("Result: ",out())
    


#h6.4

import functools
def add(a,b):
    return a+b
lst=[10,40,50,80]
print("List: ",lst)
res=functools.reduce(add,lst)
print("Sum of elements in list: ",res)
