def max2(a,b):
    return a>b
def max3(n1,n2,n3):
    if(max2(n1,n2) and max2(n1,n3)):
            return n1
    elif(max2(n2,n3) and max2(n2,n1)):
            return n2
    else:
        return n3
#n1=int(inpur("Enter the 1st number: "))
#n2=int(inpur("Enter the 1st number: "))
#n3=int(inpur("Enter the 1st number: "))
print("max number: ",max3(20,10,30))
