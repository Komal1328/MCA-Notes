#variable length argument
def no(arg1,*vartuple):
    print("Output is")
    print(arg1)
    for var in vartuple:
        print(var)
    return
no(10)
no(70,80,90)
