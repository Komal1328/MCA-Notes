dict1={('name','usn'):('zara','1ms22mca45'),'age':9}
#print(dict1)

#print('name:',dict1[('name','usn')])
dict1[('name','usn')]=['angle','1ms13mca50']
#print('name:',dict1[('name','usn')])
dict2={('name','usn'):('zara','1ms13mca45')}
#print('name:',dict2[('name','usn')])

#print(str(dict2))
print(len(dict2))

car={
    "brand":"ford",
    "model":"MMM",
    "year":1964
    }
x=car.copy()
print(x)
x['brand']="Maruti"
print(x)
print(car)
