#my_dict={}
my_dict={1:'apple',2:'ball'}
#print("Dictionary with integer keys:",my_dict)
my_dict={'name':'John',1:[2,3,4]}
#print("Dictionary with mixed keys:",my_dict)


#using dict()

my_dict=({1:'apple',2:'ball'})
#print("Dictionary using dist():",my_dict)
#print()
#sequence each item as pair
my_dict=({(1,'apple'),(2,'ball')})
#print("Dictionary with integer keys:",my_dict)

dict={'Name':'Zara','Age':7,'Class':'First'}
#print("dict['Name']:",dict['Name'])
#print("dict['Age']:",dict['Age'])
#print(dict)
dict['Age']=8
dict['school']="DPS school"
print(dict)

del dict['Name']
#print(dict)
dict.clear()
#print(dict)
del dict
#print(dict)
#print("Dict['Age']",dict['Age'])

dict1={'Name':'Zara','Name':'Manni'}
#print("dict1['Name']:",dict1['Name'])




