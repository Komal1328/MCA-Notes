def printinfo(name,age=25):
    print("name: ",name,"age :",age)
    return
printinfo('mikki',50)
printinfo(30,'abcd') #first variable is taken as name and second as age      
printinfo(age=30,name="John")
printinfo('Sam') #second argument is default value

