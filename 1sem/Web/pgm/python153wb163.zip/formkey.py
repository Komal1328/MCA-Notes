x=('key1','key2','key3')
y=0
thisdict=dict.formkey(x)
print(thisdict)
